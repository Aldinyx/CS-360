package com.example.robertrossmancs360finalproject;

import java.util.ArrayList;
import java.util.Date;

public class Event
{
    public static ArrayList<Event> eventArrayList = new ArrayList<>();
    public static String EVENT_EDIT_EXTRA =  "eventEdit";

    private int id;
    private String title;
    private int year;
    private int month;
    private int day;
    private int hour;
    private int minute;
    private Date deleted;

    public Event(int id, String title,
                 int year, int month, int day,
                 int hour, int minute, Date deleted)
    {
        this.id = id;
        this.title = title;
        this.year = year;
        this.month = month;
        this.day = day;
        this.hour = hour;
        this.minute = minute;
        this.deleted = deleted;
    }
    public Event(int id, String title,
                 int year, int month, int day,
                 int hour, int minute)
    {
        this.id = id;
        this.title = title;
        this.year = year;
        this.month = month;
        this.day = day;
        this.hour = hour;
        this.minute = minute;
        this.deleted = null;
    }
    public static Event getEventForID(int passedEventID)
    {
        for (Event event : eventArrayList)
        {
            if(event.getId() == passedEventID)
                return event;
        }
        // return null if no event with matching ID was found
        return null;
    }
    public static ArrayList<Event> nonDeletedEvents()
    {
        ArrayList<Event> nonDeleted = new ArrayList<>();
        // Add every Event that does not have a deleted date
        // to the nonDeleted list
        for(Event event : eventArrayList)
        {
            if(event.getDeleted() == null)
                nonDeleted.add(event);
        }

        return nonDeleted;
    }
    public int getId()
    {
        return id;
    }
    public void setId(int id)
    {
        this.id = id;
    }
    public String getTitle()
    {
        return title;
    }
    public void setTitle(String title)
    {
        this.title = title;
    }
    public int getYear() {
        return year;
    }
    public void setYear(int year) {
        this.year = year;
    }
    public int getMonth() {
        return month;
    }
    public void setMonth(int month) {
        this.month = month;
    }
    public int getDay() {
        return day;
    }
    public void setDay(int day) {
        this.day = day;
    }
    public int getHour() {
        return hour;
    }
    public void setHour(int hour) {
        this.hour = hour;
    }
    public int getMinute() {
        return minute;
    }
    public void setMinute(int minute) {
        this.minute = minute;
    }
    public Date getDeleted()
    {
        return deleted;
    }
    public void setDeleted(Date deleted)
    {
        this.deleted = deleted;
    }
}