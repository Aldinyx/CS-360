package com.example.robertrossmancs360finalproject;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity
{
    final int PERMISSIONS_REQUEST_CODE = 1;
    final String[] permissions = new String[]{Manifest.permission.SEND_SMS,
            Manifest.permission.READ_PHONE_NUMBERS,
            Manifest.permission.READ_PHONE_STATE};
    private ListView eventListView;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        initWidgets();
        loadFromDBToMemory();
        setEventAdapter();
        setOnClickListener();
        requestNeededPermissions();
    }
    private void initWidgets()
    {
        eventListView = findViewById(R.id.eventListView);
    }
    private void loadFromDBToMemory() // populates the database when the app is first opened
    {
        EventSQLiteManager eventSqLiteManager = EventSQLiteManager.instanceOfDatabase(this);
        eventSqLiteManager.populateEventListArray();
    }
    private void setEventAdapter()
    {
        EventAdapter eventAdapter = new EventAdapter(getApplicationContext(), Event.nonDeletedEvents());
        eventListView.setAdapter(eventAdapter);
    }
    private void setOnClickListener()
    {
        eventListView.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l)
            {
                Event selectedEvent = (Event) eventListView.getItemAtPosition(position);
                Intent editEventIntent = new Intent(getApplicationContext(), EventDetailsActivity.class);
                editEventIntent.putExtra(Event.EVENT_EDIT_EXTRA, selectedEvent.getId());
                startActivity(editEventIntent);
            }
        });
    }
    private void requestNeededPermissions() {
        if (!SendSMSService.checkPermissions(this)) {
            ActivityCompat.requestPermissions(this, permissions, PERMISSIONS_REQUEST_CODE);
        }
    }
    public void newEvent(View view)
    {
        Intent newEventIntent = new Intent(this, EventDetailsActivity.class);
        startActivity(newEventIntent);
    }
    @Override
    protected void onResume()
    {
        super.onResume();
        setEventAdapter();
        if (SendSMSService.checkPermissions(this)) {
            Intent intent = new Intent(MainActivity.this, SendSMSService.class);
            startService(intent);
        }
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Intent intent = new Intent(MainActivity.this, SendSMSService.class);
        stopService(intent);
    }
}