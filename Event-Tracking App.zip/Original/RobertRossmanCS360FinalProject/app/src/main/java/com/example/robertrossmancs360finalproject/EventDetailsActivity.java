package com.example.robertrossmancs360finalproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;

import java.util.Date;

public class EventDetailsActivity extends AppCompatActivity
{
    private EditText titleEditText;
    private DatePicker datePicker;
    private TimePicker timePicker;
    private Button deleteButton;
    private Event selectedEvent;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_details);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        initWidgets();
        checkForEditEvent();
    }
    private void initWidgets()
    {
        titleEditText = findViewById(R.id.titleEditText);
        datePicker = findViewById(R.id.datePicker);
        timePicker = findViewById(R.id.timePicker);
        deleteButton = findViewById(R.id.deleteEventButton);
    }
    private void checkForEditEvent()
    {
        Intent previousIntent = getIntent();

        int passedEventID = previousIntent.getIntExtra(Event.EVENT_EDIT_EXTRA, -1);
        selectedEvent = Event.getEventForID(passedEventID);
        // if an existing Event is being edited, populate the
        // edit text fields with the corresponding Event values
        if (selectedEvent != null)
        {
            titleEditText.setText(selectedEvent.getTitle());
            // Populate date picker with saved Year, Month, and Day
            datePicker.updateDate(selectedEvent.getYear(),selectedEvent.getMonth(),selectedEvent.getDay());
            // Populate time picker with saved Hour and Minute
            timePicker.setHour(selectedEvent.getHour());
            timePicker.setMinute(selectedEvent.getMinute());
        }
        else
        {
            // hide the delete button if a new Event is being added
            deleteButton.setVisibility(View.INVISIBLE);
        }
    }
    public void saveEvent(View view)
    {
        EventSQLiteManager eventSqLiteManager = EventSQLiteManager.instanceOfDatabase(this);
        String title = String.valueOf(titleEditText.getText());
        // Date variables
        int year = datePicker.getYear();
        int month = datePicker.getMonth();
        int day = datePicker.getDayOfMonth();
        // Time variables
        int hour = timePicker.getHour();
        int minute = timePicker.getMinute();

        // if Event did not exist prior
        if(selectedEvent == null)
        {
            int id = Event.eventArrayList.size();
            Event newEvent = new Event(id, title, year, month, day, hour, minute);
            Event.eventArrayList.add(newEvent);
            // ensure new Event is also added to the database
            eventSqLiteManager.addEventToDatabase(newEvent);
        }
        else // editing an existing Event
        {
            selectedEvent.setTitle(title);
            selectedEvent.setYear(year);
            selectedEvent.setMonth(month);
            selectedEvent.setDay(day);
            selectedEvent.setHour(hour);
            selectedEvent.setMinute(minute);
            eventSqLiteManager.updateEventInDB(selectedEvent);
        }

        finish();
    }
    public void deleteEvent(View view)
    {
        selectedEvent.setDeleted(new Date());
        EventSQLiteManager eventSqLiteManager = EventSQLiteManager.instanceOfDatabase(this);
        eventSqLiteManager.updateEventInDB(selectedEvent);
        finish();
    }
}