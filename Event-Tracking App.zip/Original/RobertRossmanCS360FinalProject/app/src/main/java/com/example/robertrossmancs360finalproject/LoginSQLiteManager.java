package com.example.robertrossmancs360finalproject;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class LoginSQLiteManager extends SQLiteOpenHelper
{
    private static LoginSQLiteManager loginSqLiteManager;

    private static final String DATABASE_NAME = "LoginDB";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_NAME = "Login";
    private static final String COUNTER = "Counter";

    private static final String ID_FIELD = "id";
    private static final String USERNAME_FIELD = "username";
    private static final String PASSWORD_FIELD = "password";
//    private static final String DELETED_FIELD = "deleted";

//    @SuppressLint("SimpleDateFormat")
//    private static final DateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");

    public LoginSQLiteManager(Context context)
    {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    public static LoginSQLiteManager instanceOfDatabase(Context context)
    {
        if(loginSqLiteManager == null)
            loginSqLiteManager = new LoginSQLiteManager(context);

        return loginSqLiteManager;
    }
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase)
    {
        StringBuilder sql;
        sql = new StringBuilder()
                .append("CREATE TABLE ")
                .append(TABLE_NAME)
                .append("(")
                .append(COUNTER)
                .append(" INTEGER PRIMARY KEY AUTOINCREMENT, ")
                .append(ID_FIELD)
                .append(" INT, ")
                .append(USERNAME_FIELD)
                .append(" TEXT, ")
                .append(PASSWORD_FIELD)
//                .append(DELETED_FIELD)
                .append(" TEXT)");

        sqLiteDatabase.execSQL(sql.toString());
    }
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) { }
    public void addLoginToDatabase(Login login)
    {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(ID_FIELD, login.getId());
        contentValues.put(USERNAME_FIELD, login.getUsername());
        contentValues.put(PASSWORD_FIELD, login.getPassword());
//        contentValues.put(DELETED_FIELD, getStringFromDate(login.getDeleted()));

        sqLiteDatabase.insert(TABLE_NAME, null, contentValues);
    }
    public void populateLoginListArray()
    {
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();

        try (Cursor result = sqLiteDatabase.rawQuery("SELECT * FROM " + TABLE_NAME, null))
        {
            if(result.getCount() != 0)
            {
                while (result.moveToNext())
                {
                    int id = result.getInt(1);
                    String username = result.getString(2);
                    String password = result.getString(3);
//                    String stringDeleted = result.getString(8);
//                    Date deleted = getDateFromString(stringDeleted);
                    Login login = new Login(id,username,password);
                    Login.loginArrayList.add(login);
                }
            }
        }
    }
    public void updateLoginInDB(Login login)
    {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(ID_FIELD, login.getId());
        contentValues.put(USERNAME_FIELD, login.getUsername());
        contentValues.put(PASSWORD_FIELD, login.getPassword());
//        contentValues.put(DELETED_FIELD, getStringFromDate(login.getDeleted()));

        sqLiteDatabase.update(TABLE_NAME, contentValues, ID_FIELD + " =? ", new String[]{String.valueOf(login.getId())});
    }
//    private String getStringFromDate(Date date)
//    {
//        if(date == null)
//            return null;
//        return dateFormat.format(date);
//    }
//    private Date getDateFromString(String string)
//    {
//        try
//        {
//            return dateFormat.parse(string);
//        }
//        catch (ParseException | NullPointerException e)
//        {
//            return null;
//        }
//    }
}