package com.example.robertrossmancs360finalproject;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class EventSQLiteManager extends SQLiteOpenHelper
{
    private static EventSQLiteManager eventSqLiteManager;

    private static final String DATABASE_NAME = "EventDB";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_NAME = "Event";
    private static final String COUNTER = "Counter";

    private static final String ID_FIELD = "id";
    private static final String TITLE_FIELD = "title";
    private static final String YEAR_FIELD = "year";
    private static final String MONTH_FIELD = "month";
    private static final String DAY_FIELD = "day";
    private static final String HOUR_FIELD = "hour";
    private static final String MINUTE_FIELD = "minute";
    private static final String DELETED_FIELD = "deleted";

    @SuppressLint("SimpleDateFormat")
    private static final DateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");

    public EventSQLiteManager(Context context)
    {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    public static EventSQLiteManager instanceOfDatabase(Context context)
    {
        if(eventSqLiteManager == null)
            eventSqLiteManager = new EventSQLiteManager(context);

        return eventSqLiteManager;
    }
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase)
    {
        StringBuilder sql;
        sql = new StringBuilder()
                .append("CREATE TABLE ")
                .append(TABLE_NAME)
                .append("(")
                .append(COUNTER)
                .append(" INTEGER PRIMARY KEY AUTOINCREMENT, ")
                .append(ID_FIELD)
                .append(" INT, ")
                .append(TITLE_FIELD)
                .append(" TEXT, ")
                .append(YEAR_FIELD)
                .append(" INT, ")
                .append(MONTH_FIELD)
                .append(" INT, ")
                .append(DAY_FIELD)
                .append(" INT, ")
                .append(HOUR_FIELD)
                .append(" INT, ")
                .append(MINUTE_FIELD)
                .append(" INT, ")
                .append(DELETED_FIELD)
                .append(" TEXT)");

        sqLiteDatabase.execSQL(sql.toString());
    }
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) { }
    public void addEventToDatabase(Event event)
    {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(ID_FIELD, event.getId());
        contentValues.put(TITLE_FIELD, event.getTitle());
        contentValues.put(YEAR_FIELD, event.getYear());
        contentValues.put(MONTH_FIELD, event.getMonth());
        contentValues.put(DAY_FIELD, event.getDay());
        contentValues.put(HOUR_FIELD, event.getHour());
        contentValues.put(MINUTE_FIELD, event.getMinute());
        contentValues.put(DELETED_FIELD, getStringFromDate(event.getDeleted()));

        sqLiteDatabase.insert(TABLE_NAME, null, contentValues);
    }
    public void populateEventListArray()
    {
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        // Clear list before populating to avoid duplicates
        Event.eventArrayList.clear();

        try (Cursor result = sqLiteDatabase.rawQuery("SELECT * FROM " + TABLE_NAME, null))
        {
            if(result.getCount() != 0)
            {
                while (result.moveToNext())
                {
                    int id = result.getInt(1);
                    String title = result.getString(2);
                    int year = result.getInt(3);
                    int month = result.getInt(4);
                    int day = result.getInt(5);
                    int hour = result.getInt(6);
                    int minute = result.getInt(7);
                    String stringDeleted = result.getString(8);
                    Date deleted = getDateFromString(stringDeleted);
                    Event event = new Event(id,title,year,month,day,hour,minute,deleted);
                    Event.eventArrayList.add(event);
                }
            }
        }
    }
    public void updateEventInDB(Event event)
    {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(ID_FIELD, event.getId());
        contentValues.put(TITLE_FIELD, event.getTitle());
        contentValues.put(YEAR_FIELD, event.getYear());
        contentValues.put(MONTH_FIELD, event.getMonth());
        contentValues.put(DAY_FIELD, event.getDay());
        contentValues.put(HOUR_FIELD, event.getHour());
        contentValues.put(MINUTE_FIELD, event.getMinute());
        contentValues.put(DELETED_FIELD, getStringFromDate(event.getDeleted()));

        sqLiteDatabase.update(TABLE_NAME, contentValues, ID_FIELD + " =? ", new String[]{String.valueOf(event.getId())});
    }
    private String getStringFromDate(Date date)
    {
        if(date == null)
            return null;
        return dateFormat.format(date);
    }
    private Date getDateFromString(String string)
    {
        try
        {
            return dateFormat.parse(string);
        }
        catch (ParseException | NullPointerException e)
        {
            return null;
        }
    }
}