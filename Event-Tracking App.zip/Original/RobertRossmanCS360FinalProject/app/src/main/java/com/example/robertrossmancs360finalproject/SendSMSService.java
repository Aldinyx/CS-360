package com.example.robertrossmancs360finalproject;

import android.Manifest;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.CountDownTimer;
import android.os.IBinder;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import java.util.Calendar;

public class SendSMSService extends Service {
    private CountDownTimer countDownTimer;
    private boolean isRunning = false;

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!isRunning) {
            isRunning = true;
            // Check every minute to send a notification
            // if an event is happening today
            countDownTimer = new CountDownTimer(60000, 60000) {
                @Override
                public void onFinish() {
                    checkForEventsHappeningToday();
                    start();
                }

                @Override
                public void onTick(long millisUntilFinished) {
                }
            }.start();
        }
        // Makes service restart if it stops from the system running out of memory
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        isRunning = false;
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void checkForEventsHappeningToday() {
        Calendar calendar = Calendar.getInstance();
        for (Event event : Event.eventArrayList) {
            if (event.getDay() == calendar.get(Calendar.DAY_OF_MONTH) &&
                    event.getMonth() == calendar.get(Calendar.MONTH) &&
                    event.getYear() == calendar.get(Calendar.YEAR)) {
                sendSMS(event.getTitle());
            }
        }
    }
    private void sendSMS(String eventTitle) {
        if (!checkPermissions(getApplicationContext())) return;
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(getCurrentPhoneNumber(), null,
                eventTitle + " is today!", null, null);
    }
    String getCurrentPhoneNumber() {
        TelephonyManager telephonyManager;
        telephonyManager = (TelephonyManager)getApplicationContext().getSystemService(TELEPHONY_SERVICE);
        return telephonyManager.getLine1Number();
    }
    private static boolean checkPermission(Context context, String permission) {
        int check = ContextCompat.checkSelfPermission(context, permission);
        return (check == PackageManager.PERMISSION_GRANTED);
    }
    public static boolean checkPermissions(Context context) {
        return checkPermission(context, Manifest.permission.SEND_SMS) &&
                checkPermission(context, Manifest.permission.READ_PHONE_NUMBERS) &&
                checkPermission(context, Manifest.permission.READ_PHONE_STATE);
    }
}