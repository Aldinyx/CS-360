package com.example.robertrossmancs360finalproject;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends AppCompatActivity
{
    final int PERMISSIONS_REQUEST_CODE = 1;
    final String[] permissions = new String[]{Manifest.permission.SEND_SMS,
            Manifest.permission.READ_PHONE_NUMBERS,
            Manifest.permission.READ_PHONE_STATE};
    private ListView eventListView;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        Log.v("MainActivity", "initWidgets()");
        initWidgets();
        Log.v("MainActivity", "loadFromDBToMemory()");
        loadFromDBToMemory();
        Log.v("MainActivity", "setEventAdapter()");
        setEventAdapter();
        Log.v("MainActivity", "setOnClickListener()");
        setOnClickListener();
        Log.v("MainActivity", "requestNeededPermissions()");
        requestNeededPermissions();
    }
    private void initWidgets()
    {
        eventListView = findViewById(R.id.eventListView);
    }
    private void loadFromDBToMemory() // populates the database when the app is first opened
    {
        EventSQLiteManager eventSqLiteManager = EventSQLiteManager.instanceOfDatabase(this);
        Log.v("MainActivity", "loadFromDBToMemory()-populateEventListArray()");
        eventSqLiteManager.populateEventListArray();
    }
    private void setEventAdapter()
    {
        EventAdapter eventAdapter = new EventAdapter(getApplicationContext(),
                getSortedListOfEventsByPriority(Event.nonDeletedEvents()));
        eventListView.setAdapter(eventAdapter);
    }
    private List<Event> getSortedListOfEventsByPriority(List<Event> events)
    {
        // create a copy of the list to sort
        List<Event> sortedList = new ArrayList<>(events);
        // create an instance of the SortEventByPriority Comparator
        Comparator newComparator = new SortEventByPriority();
        // sort the list using the Comparator
        // .reversed() is used to sort the Events in
        // descending order of priority
        sortedList.sort(newComparator.reversed());
        return sortedList;
    }
    private void setOnClickListener()
    {
        eventListView.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l)
            {
                Event selectedEvent = (Event) eventListView.getItemAtPosition(position);
                Intent editEventIntent = new Intent(getApplicationContext(), EventDetailsActivity.class);
                editEventIntent.putExtra(Event.EVENT_EDIT_EXTRA, selectedEvent.getId());
                startActivity(editEventIntent);
            }
        });
    }
    private void requestNeededPermissions() {
        if (!SendNotificationService.checkPermissions(this)) {
            ActivityCompat.requestPermissions(this, permissions, PERMISSIONS_REQUEST_CODE);
        }
    }
    public void newEvent(View view)
    {
        Intent newEventIntent = new Intent(this, EventDetailsActivity.class);
        startActivity(newEventIntent);
    }
    @Override
    protected void onResume()
    {
        super.onResume();
        setEventAdapter();
        Intent intent;
        intent = new Intent(MainActivity.this, SendNotificationService.class);
        startService(intent);
        intent = new Intent(MainActivity.this, ConcludeEventService.class);
        startService(intent);
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Intent intent;
        intent = new Intent(MainActivity.this, SendNotificationService.class);
        stopService(intent);
        intent = new Intent(MainActivity.this, ConcludeEventService.class);
        stopService(intent);
    }
}