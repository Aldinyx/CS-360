package com.example.robertrossmancs360finalproject;

import android.Manifest;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.CountDownTimer;
import android.os.IBinder;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import java.util.Calendar;

public class SendNotificationService extends Service {
    private CountDownTimer countDownTimer;
    private boolean isRunning = false;

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!isRunning) {
            // perform a check immediately when service starts
            checkForEventsHappeningToday();
            isRunning = true;
            // Check every 6 hours to send a notification
            // if an event is happening today
            countDownTimer = new CountDownTimer(129600000, 129600000) {
                @Override
                public void onFinish() {
                    checkForEventsHappeningToday();
                    start();
                }

                @Override
                public void onTick(long millisUntilFinished) {
                }
            }.start();
        }
        // Makes service restart if it stops from the system running out of memory
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        isRunning = false;
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void checkForEventsHappeningToday() {
        Calendar calendar = Calendar.getInstance(); // get Calendar with current date
        for (Event event : Event.eventArrayList) {  // iterate through all stored events
            // check if each event is happening today
            checkIfEventIsHappeningToday(event, calendar);
        }
    }
    public void checkIfEventIsHappeningToday(Event event, Calendar calendar) {
        // check if event has not sent a notification & is happening today
        if (!event.getSentNotification() && event.isEventHappeningOnGivenDate(calendar))
        {
            if (event.getNotificationSetting() == 0)
            {
                // send notification
                sendSMS(event.getTitle());
            }
            // prevent duplicate notifications
            event.setSentNotification(true);
            EventSQLiteManager.instanceOfDatabase(this).updateEventInDB(event);
            // add event to an array list that will be used
            // to determine when the event concludes
            Event.eventsHappeningSoonArrayList.add(event);
        }
    }
    private void sendSMS(String eventTitle) {
        if (!checkPermissions(getApplicationContext())) return;
        SmsManager smsManager = SmsManager.getDefault();
        String phoneNumber = getCurrentPhoneNumber();
        if (phoneNumber == null) return;
        smsManager.sendTextMessage(phoneNumber, null,
                eventTitle + " is today!", null, null);
    }
    String getCurrentPhoneNumber() {
        if (!checkPermission(this, Manifest.permission.READ_PHONE_STATE)) return null;
        TelephonyManager telephonyManager;
        telephonyManager = (TelephonyManager)getApplicationContext().getSystemService(TELEPHONY_SERVICE);
        return telephonyManager.getLine1Number();
    }
    private static boolean checkPermission(Context context, String permission) {
        int check = ContextCompat.checkSelfPermission(context, permission);
        return (check == PackageManager.PERMISSION_GRANTED);
    }
    public static boolean checkPermissions(Context context) {
        return checkPermission(context, Manifest.permission.SEND_SMS) &&
                checkPermission(context, Manifest.permission.READ_PHONE_NUMBERS) &&
                checkPermission(context, Manifest.permission.READ_PHONE_STATE);
    }
}