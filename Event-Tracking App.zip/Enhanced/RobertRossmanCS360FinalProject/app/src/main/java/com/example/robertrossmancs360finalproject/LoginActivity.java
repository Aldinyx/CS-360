package com.example.robertrossmancs360finalproject;

import static android.view.View.VISIBLE;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class LoginActivity extends AppCompatActivity {
    private EditText usernameEditText;
    private EditText passwordEditText;
    private TextView invalidLoginTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        initWidgets();
        loadFromDBToMemory();
    }
    private void initWidgets()
    {
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        invalidLoginTextView = findViewById(R.id.invalidLoginText);
    }
    private void loadFromDBToMemory()
    {
        LoginSQLiteManager loginSqLiteManager = LoginSQLiteManager.instanceOfDatabase(this);
        loginSqLiteManager.populateLoginListArray();
    }
    public void attemptLogin(View view) {
        String username = String.valueOf(usernameEditText.getText());
        String password = String.valueOf(passwordEditText.getText());
        if (Login.validateLogin(username, password)) {
            login();
        }
        else {
            invalidLoginTextView.setVisibility(VISIBLE);
        }
    }
    public void saveLogin(View view)
    {
        LoginSQLiteManager loginSqLiteManager = LoginSQLiteManager.instanceOfDatabase(this);
        String username = String.valueOf(usernameEditText.getText());
        String password = String.valueOf(passwordEditText.getText());

        int id = Login.loginArrayList.size();
        Login newLogin = new Login(id, username, password);
        Login.loginArrayList.add(newLogin);
        loginSqLiteManager.addLoginToDatabase(newLogin);
        login();
    }
    void login() {
        Intent mainActivityIntent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(mainActivityIntent);
    }
}