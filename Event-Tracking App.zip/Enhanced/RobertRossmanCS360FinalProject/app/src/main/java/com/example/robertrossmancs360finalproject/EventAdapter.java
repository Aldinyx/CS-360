package com.example.robertrossmancs360finalproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class EventAdapter extends ArrayAdapter<Event>
{
    private static final String SORTING_PRIORITY_START = "Priority: ";
    public EventAdapter(Context context, List<Event> events)
    {
        super(context, 0, events);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent)
    {
        Event event = getItem(position);
        if(convertView == null)
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.event_cell, parent, false);

        TextView title = convertView.findViewById(R.id.cellTitle);
        TextView date = convertView.findViewById(R.id.cellDate);
        TextView time = convertView.findViewById(R.id.cellTime);
        TextView sortingPriority = convertView.findViewById(R.id.cellSortingPriority);

        if (event != null)
        {
            title.setText(event.getTitle());

            date.setText(getStringFromDateInts(event.getYear(),event.getMonth(),event.getDay()));
            time.setText(getStringFromTimeInts(event.getHour(), event.getMinute()));

            sortingPriority.setText(SORTING_PRIORITY_START + event.getSortingPriority());
        }

        return convertView;
    }
    String getStringFromDateInts(int year, int month, int day){
        StringBuilder stringToReturn;
        stringToReturn = new StringBuilder()
                .append(getMonthFromInt(month))
                .append(" ")
                .append(day)
                .append(", ")
                .append(year);
        return stringToReturn.toString();
    }
    String getMonthFromInt(int monthInt) {
        switch (monthInt) {
            case 0:
                return "Jan";
            case 1:
                return "Feb";
            case 2:
                return "Mar";
            case 3:
                return "Apr";
            case 4:
                return "May";
            case 5:
                return "Jun";
            case 6:
                return "Jul";
            case 7:
                return "Aug";
            case 8:
                return "Sep";
            case 9:
                return "Oct";
            case 10:
                return "Nov";
            case 11:
                return "Dec";
        }
        return null;
    }
    String getStringFromTimeInts(int hour, int minute){
        StringBuilder stringToReturn;
        stringToReturn = new StringBuilder()
                .append(get12HourIntFrom24HourInt(hour))
                .append(":")
                .append(getIntAsStringWithLeadingZero(minute))
                .append(" ")
                .append(getMeridiemFrom24HourInt(hour));
        return stringToReturn.toString();
    }
    public static int get12HourIntFrom24HourInt(int hour) {
       if (hour > 12) {
           hour -= 12;
       }
       else if (hour == 0) {
           hour = 12;
       }
       return hour;
    }
    String getIntAsStringWithLeadingZero(int originalInt) {
        if (originalInt < 10) {
            return "0" + originalInt;
        }
        return String.valueOf(originalInt);
    }
    String getMeridiemFrom24HourInt(int hour) {
        if (hour >= 12) {
            return "PM";
        }
        else {
            return "AM";
        }
    }
}