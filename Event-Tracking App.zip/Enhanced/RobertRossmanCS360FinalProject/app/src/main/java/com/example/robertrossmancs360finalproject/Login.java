package com.example.robertrossmancs360finalproject;

import java.util.ArrayList;

public class Login
{
    public static ArrayList<Login> loginArrayList = new ArrayList<>();

    private int id;
    private String username;
    private String password;

    public Login(int id, String username, String password)
    {
        this.id = id;
        this.username = username;
        this.password = password;
    }
    public static boolean validateLogin(String username, String password)
    {
        for (Login login : loginArrayList)
        {
            if(login.getUsername().equals(username) && login.getPassword().equals(password))
                return true;
        }
        return false;
    }
    public int getId()
    {
        return id;
    }
    public void setId(int id)
    {
        this.id = id;
    }
    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
}