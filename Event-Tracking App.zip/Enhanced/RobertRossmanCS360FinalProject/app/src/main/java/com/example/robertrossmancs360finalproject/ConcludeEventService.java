package com.example.robertrossmancs360finalproject;

import android.app.Service;
import android.content.Intent;
import android.os.CountDownTimer;
import android.os.IBinder;

import androidx.annotation.Nullable;

import java.time.LocalTime;
import java.util.Calendar;
import java.util.Date;

public class ConcludeEventService extends Service {
    private CountDownTimer countDownTimer;
    private boolean isRunning = false;

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!isRunning) {
            // perform a check immediately when service starts
            checkForEventsThatHaveFinished();
            isRunning = true;
            // Check every minute to conclude any events that have finished
            countDownTimer = new CountDownTimer(60000, 60000) {
                @Override
                public void onFinish() {
                    // conclude any events that have finished as of this minute
                    checkForEventsThatHaveFinished();
                    start();   // repeat timer if there are still events today
                }

                @Override
                public void onTick(long millisUntilFinished) {
                }
            }.start();
        }
        // Makes service restart if it stops from the system running out of memory
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        isRunning = false;
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void checkForEventsThatHaveFinished() {
        LocalTime localTime = LocalTime.now(); // get LocalTime with current time
        Event currentEvent;
        // iterate through all stored events happening today
        for (int i = Event.eventsHappeningSoonArrayList.size() - 1; i > -1; i--) {
            currentEvent = Event.eventsHappeningSoonArrayList.get(i);
            // conclude event if it is happening today
            if (currentEvent.hasEventFinished(localTime))
            {
                concludeEvent(currentEvent);
            }
        }
    }
    private void concludeEvent(Event eventToConclude)
    {
        Event.eventsHappeningSoonArrayList.remove(eventToConclude);
        int daysTillRecurrence = eventToConclude.getRecurrencePeriod();
        if (daysTillRecurrence > 0) // if event should recur, increase event's date accordingly
        {
            makeEventRecur(eventToConclude, daysTillRecurrence);
        }
        else // if event should not recur, set event to be deleted
        {
            eventToConclude.setDeleted(new Date());
        }
        // either way, update event in database
        EventSQLiteManager eventSqLiteManager = EventSQLiteManager.instanceOfDatabase(this);
        eventSqLiteManager.updateEventInDB(eventToConclude);
    }
    void makeEventRecur(Event event, int daysLaterToRecur) {
        Calendar calendar = Calendar.getInstance(); // get current date
        // make the Calendar lenient to let the date rollover if adding
        // an amount of days that surpasses the number of days in the month/year
        calendar.setLenient(true);
        calendar.add(Calendar.DAY_OF_YEAR, daysLaterToRecur);
        // update event with new date
        event.setDay(calendar.get(Calendar.DAY_OF_MONTH));
        event.setMonth(calendar.get(Calendar.MONTH));
        event.setYear(calendar.get(Calendar.YEAR));
        // reset sentNotification flag
        event.setSentNotification(false);
    }
}