package com.example.robertrossmancs360finalproject;

import java.util.Comparator;

public class SortEventByPriority implements Comparator {
    @Override
    public int compare(Object o1, Object o2) {
        // convert Objects to Events, then compare their
        // sortingPriorities using Integer.compare
        // returns -1 if o1 < o2, 1 if o1 > o2, and 0 if both are equal
        return Integer.compare(
                ((Event) o1).getSortingPriority(),
                ((Event) o2).getSortingPriority());
    }
}
