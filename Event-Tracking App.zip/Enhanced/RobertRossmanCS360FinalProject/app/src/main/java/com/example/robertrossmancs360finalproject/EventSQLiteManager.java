package com.example.robertrossmancs360finalproject;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class EventSQLiteManager extends SQLiteOpenHelper
{
    private static EventSQLiteManager eventSqLiteManager;

    private static final String DATABASE_NAME = "EventDB";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_NAME = "Event";
    private static final String COUNTER = "Counter";

    private static final String ID_FIELD = "id";
    private static final String TITLE_FIELD = "title";
    private static final String YEAR_FIELD = "year";
    private static final String MONTH_FIELD = "month";
    private static final String DAY_FIELD = "day";
    private static final String HOUR_FIELD = "hour";
    private static final String MINUTE_FIELD = "minute";
    private static final String NOTIFICATION_SETTING = "notificationSetting";
    private static final String DAYS_TILL_RECURRENCE = "daysTillRecurrence";
    private static final String SORTING_PRIORITY = "sortingPriority";
    private static final String SENT_NOTIFICATION = "sentNotification";
    private static final String DELETED_FIELD = "deleted";

    @SuppressLint("SimpleDateFormat")
    private static final DateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");

    public EventSQLiteManager(Context context)
    {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    public static EventSQLiteManager instanceOfDatabase(Context context)
    {
        if(eventSqLiteManager == null)
            eventSqLiteManager = new EventSQLiteManager(context);

        return eventSqLiteManager;
    }
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase)
    {
        StringBuilder sql;
        sql = new StringBuilder()
                .append("CREATE TABLE ")
                .append(TABLE_NAME)
                .append("(")
                .append(COUNTER)
                .append(" INTEGER PRIMARY KEY AUTOINCREMENT, ")
                .append(ID_FIELD)
                .append(" INT, ")
                .append(TITLE_FIELD)
                .append(" TEXT, ")
                .append(YEAR_FIELD)
                .append(" INT, ")
                .append(MONTH_FIELD)
                .append(" INT, ")
                .append(DAY_FIELD)
                .append(" INT, ")
                .append(HOUR_FIELD)
                .append(" INT, ")
                .append(MINUTE_FIELD)
                .append(" INT, ")
                .append(NOTIFICATION_SETTING)
                .append(" INT, ")
                .append(DAYS_TILL_RECURRENCE)
                .append(" INT, ")
                .append(SORTING_PRIORITY)
                .append(" INT, ")
                .append(SENT_NOTIFICATION)
                .append(" BOOLEAN, ")
                .append(DELETED_FIELD)
                .append(" TEXT)");

        sqLiteDatabase.execSQL(sql.toString());
    }
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) { }
    public void addEventToDatabase(Event event)
    {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(ID_FIELD, event.getId());
        contentValues.put(TITLE_FIELD, event.getTitle());
        contentValues.put(YEAR_FIELD, event.getYear());
        contentValues.put(MONTH_FIELD, event.getMonth());
        contentValues.put(DAY_FIELD, event.getDay());
        contentValues.put(HOUR_FIELD, event.getHour());
        contentValues.put(MINUTE_FIELD, event.getMinute());
        contentValues.put(NOTIFICATION_SETTING, event.getNotificationSetting());
        contentValues.put(DAYS_TILL_RECURRENCE, event.getRecurrencePeriod());
        contentValues.put(SORTING_PRIORITY, event.getSortingPriority());
        contentValues.put(SENT_NOTIFICATION, event.getSentNotification());
        contentValues.put(DELETED_FIELD, getStringFromDate(event.getDeleted()));

        sqLiteDatabase.insert(TABLE_NAME, null, contentValues);
    }
    public void deleteEventFromDB(Event event)
    {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        sqLiteDatabase.delete(TABLE_NAME, ID_FIELD + " =? ",
                new String[] {String.valueOf(event.getId())});
    }
    public void populateEventListArray()
    {
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        // Clear list before populating to avoid duplicates
        Event.eventArrayList.clear();
        Event.eventsHappeningSoonArrayList.clear();
        Log.v("MainActivity", "populateEventListArray()-cleared");

        try (Cursor result = sqLiteDatabase.rawQuery("SELECT * FROM " + TABLE_NAME, null))
        {
            Log.v("MainActivity", "populateEventListArray()-first try passed");
            if(result.getCount() != 0)
            {
                Log.v("MainActivity", "populateEventListArray()-second try passed");
                while (result.moveToNext())
                {
                    int id = result.getInt(1);
                    Log.v("MainActivity", "populateEventListArray()-got id int");
                    String title = result.getString(2);
                    Log.v("MainActivity", "populateEventListArray()-got title string");
                    int year = result.getInt(3);
                    int month = result.getInt(4);
                    int day = result.getInt(5);
                    int hour = result.getInt(6);
                    int minute = result.getInt(7);
                    Log.v("MainActivity", "populateEventListArray()-got all date values");
                    int notificationSetting = result.getInt(8);
                    Log.v("MainActivity", "populateEventListArray()-got notificationSetting");
                    int daysTillRecurrence = result.getInt(9);
                    Log.v("MainActivity", "populateEventListArray()-got daysTillRecurrence");
                    int sortingPriority = result.getInt(10);
                    Log.v("MainActivity", "populateEventListArray()-got sortingPriority");
                    int sentNotification = result.getInt(11);
                    Log.v("MainActivity", "populateEventListArray()-got sentNotification");
                    String stringDeleted = result.getString(12);
                    Log.v("MainActivity", "populateEventListArray()-got deleted");
                    Date deleted = getDateFromString(stringDeleted);
                    Log.v("MainActivity", "populateEventListArray()-getDateFromString(stringDeleted)");
                    Log.v("MainActivity", "populateEventListArray()-while-got/set all values");
                    // add event to array list if not deleted
                    if (deleted != null) {
                        continue;
                    }
                    Event event = new Event(id,title,year,month,day,hour,minute,
                            notificationSetting,
                            daysTillRecurrence, sortingPriority,sentNotification == 1,
                            null);
                    Event.eventArrayList.add(event);
                    // if event already sent a notification,
                    // add to HappeningSoon array list
                    if (event.getSentNotification())
                        Event.eventsHappeningSoonArrayList.add(event);
                    Log.v("MainActivity", "populateEventListArray()-while iteration");
                }
            }
        }
    }
    public void updateEventInDB(Event event)
    {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(ID_FIELD, event.getId());
        contentValues.put(TITLE_FIELD, event.getTitle());
        contentValues.put(YEAR_FIELD, event.getYear());
        contentValues.put(MONTH_FIELD, event.getMonth());
        contentValues.put(DAY_FIELD, event.getDay());
        contentValues.put(HOUR_FIELD, event.getHour());
        contentValues.put(MINUTE_FIELD, event.getMinute());
        contentValues.put(NOTIFICATION_SETTING, event.getNotificationSetting());
        contentValues.put(DAYS_TILL_RECURRENCE, event.getRecurrencePeriod());
        contentValues.put(SORTING_PRIORITY, event.getSortingPriority());
        contentValues.put(SENT_NOTIFICATION, event.getSentNotification());
        contentValues.put(DELETED_FIELD, getStringFromDate(event.getDeleted()));

        sqLiteDatabase.update(TABLE_NAME, contentValues, ID_FIELD + " =? ", new String[]{String.valueOf(event.getId())});
    }
    private String getStringFromDate(Date date)
    {
        if(date == null)
            return null;
        return dateFormat.format(date);
    }
    private Date getDateFromString(String string)
    {
        try
        {
            return dateFormat.parse(string);
        }
        catch (ParseException | NullPointerException e)
        {
            return null;
        }
    }
}