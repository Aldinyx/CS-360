package com.example.robertrossmancs360finalproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.NumberPicker;
import android.widget.TimePicker;

import java.util.Date;

public class EventDetailsActivity extends AppCompatActivity
{
    private EditText titleEditText;
    private DatePicker datePicker;
    private TimePicker timePicker;
    private NumberPicker notificationSettingPicker;
    private EditText daysTillRecurrenceText;
    private NumberPicker sortingPriorityPicker;
    private Button deleteButton;
    private Event selectedEvent;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_details);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        initWidgets();
        checkForEditEvent();
    }
    private void initWidgets()
    {
        titleEditText = findViewById(R.id.titleEditText);
        datePicker = findViewById(R.id.datePicker);
        timePicker = findViewById(R.id.timePicker);
        initNotificationSettingPicker();
        daysTillRecurrenceText = findViewById(R.id.daysTillRecurrenceText);
        initSortingPriorityPicker();
        deleteButton = findViewById(R.id.deleteEventButton);
    }
    private void initNotificationSettingPicker() {
        notificationSettingPicker = findViewById(R.id.notificationSettingPicker);
        notificationSettingPicker.setMinValue(0);
        notificationSettingPicker.setMaxValue(1);
        String[] notificationSettings = new String[] {"SMS Text", "None"};
        notificationSettingPicker.setDisplayedValues(notificationSettings);
    }
    private void initSortingPriorityPicker() {
        sortingPriorityPicker = findViewById(R.id.sortingPriorityPicker);
        sortingPriorityPicker.setMinValue(1);
        sortingPriorityPicker.setMaxValue(5);
    }
    private void checkForEditEvent()
    {
        Intent previousIntent = getIntent();

        int passedEventID = previousIntent.getIntExtra(Event.EVENT_EDIT_EXTRA, -1);
        selectedEvent = Event.getEventForID(passedEventID);
        // if an existing Event is being edited, populate the
        // edit text fields with the corresponding Event values
        if (selectedEvent != null)
        {
            titleEditText.setText(selectedEvent.getTitle());
            // Populate date picker with saved Year, Month, and Day
            datePicker.updateDate(selectedEvent.getYear(),selectedEvent.getMonth(),selectedEvent.getDay());
            // Populate time picker with saved Hour and Minute
            timePicker.setHour(selectedEvent.getHour());
            timePicker.setMinute(selectedEvent.getMinute());
            // Populate notificationSetting picker with saved notificationSetting
            notificationSettingPicker.setValue(selectedEvent.getNotificationSetting());
            // Populate daysTillRecurrence text with saved daysTillRecurrence
            // If saved days value is less than 0, set to an empty string
            daysTillRecurrenceText.setText(convertDaysTillRecurrenceIntToString(selectedEvent.getRecurrencePeriod()));
            // Populate sortingPriority picker with saved sortingPriority
            sortingPriorityPicker.setValue(selectedEvent.getSortingPriority());
        }
        else
        {
            // hide the delete button if a new Event is being added
            deleteButton.setVisibility(View.INVISIBLE);
        }
    }
    public void saveEvent(View view)
    {
        EventSQLiteManager eventSqLiteManager = EventSQLiteManager.instanceOfDatabase(this);
        String title = String.valueOf(titleEditText.getText());
        // Date variables
        int year = datePicker.getYear();
        int month = datePicker.getMonth();
        int day = datePicker.getDayOfMonth();
        // Time variables
        int hour = timePicker.getHour();
        int minute = timePicker.getMinute();
        // Notification Setting
        int notificationSetting = notificationSettingPicker.getValue();
        // Days Till Recurrence variable
        int daysTillRecurrence = convertStringToInt(String.valueOf(daysTillRecurrenceText.getText()));
        // Sorting Priority
        int sortingPriority = sortingPriorityPicker.getValue();
        // if Event did not exist prior
        if(selectedEvent == null)
        {
            int id = Event.eventArrayList.size();
            Event newEvent = new Event(id, title,
                    year, month, day, hour, minute,
                    notificationSetting,
                    daysTillRecurrence, sortingPriority,
                    false);
            Event.eventArrayList.add(newEvent);
            // ensure new Event is also added to the database
            eventSqLiteManager.addEventToDatabase(newEvent);
        }
        else // editing an existing Event
        {
            selectedEvent.setTitle(title);

            // check if any date/time values have changed
            if (minute != selectedEvent.getMinute() ||
            hour != selectedEvent.getHour() ||
            day != selectedEvent.getDay() ||
            month != selectedEvent.getMonth() ||
            year != selectedEvent.getYear())
            {
                // if event already sent notification, reset sentNotification
                // flag and remove event from eventsHappeningSoonArrayList
                if (selectedEvent.getSentNotification())
                {
                    selectedEvent.setSentNotification(false);
                    Event.eventsHappeningSoonArrayList.remove(selectedEvent);
                }
                // update date/time values
                selectedEvent.setYear(year);
                selectedEvent.setMonth(month);
                selectedEvent.setDay(day);
                selectedEvent.setHour(hour);
                selectedEvent.setMinute(minute);

            }
            selectedEvent.setNotificationSetting(notificationSetting);
            selectedEvent.setRecurrencePeriod(daysTillRecurrence);
            selectedEvent.setSortingPriority(sortingPriority);
            eventSqLiteManager.updateEventInDB(selectedEvent);
        }
        finish();
    }
    int convertStringToInt(String stringToConvert)
    {
        try
        {
            return Integer.parseInt(stringToConvert);
        } catch (NumberFormatException e) {
            return 0;
        }
    }
    String convertDaysTillRecurrenceIntToString(int daysTillRecurrence)
    {
        if (daysTillRecurrence > 0)
            return String.valueOf(daysTillRecurrence);
        else
            return "";
    }
    public void deleteEvent(View view)
    {
        selectedEvent.setDeleted(new Date());
        EventSQLiteManager eventSqLiteManager = EventSQLiteManager.instanceOfDatabase(this);
//        eventSqLiteManager.updateEventInDB(selectedEvent);
        eventSqLiteManager.deleteEventFromDB(selectedEvent);
        finish();
    }
}