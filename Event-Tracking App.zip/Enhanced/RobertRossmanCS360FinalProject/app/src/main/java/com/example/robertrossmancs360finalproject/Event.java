package com.example.robertrossmancs360finalproject;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class Event
{
    public static ArrayList<Event> eventArrayList = new ArrayList<>();
    public static ArrayList<Event> eventsHappeningSoonArrayList = new ArrayList<>();
    public static String EVENT_EDIT_EXTRA =  "eventEdit";

    private int id;
    private String title;
    private int year;
    private int month;
    private int day;
    private int hour;
    private int minute;
    private int notificationSetting;
    private int recurrencePeriod;
    private int sortingPriority;
    private boolean sentNotification;
    private Date deleted;

    public Event(int id, String title,
                 int year, int month, int day,
                 int hour, int minute,
                 int notificationSetting,
                 int recurrencePeriod, int sortingPriority,
                 boolean sentNotification,
                 Date deleted)
    {
        this.id = id;
        this.title = title;
        this.year = year;
        this.month = month;
        this.day = day;
        this.hour = hour;
        this.minute = minute;
        this.notificationSetting = notificationSetting;
        this.recurrencePeriod = recurrencePeriod;
        this.sortingPriority = sortingPriority;
        this.sentNotification = sentNotification;
        this.deleted = deleted;
    }
    public Event(int id, String title,
                 int year, int month, int day,
                 int hour, int minute,
                 int notificationSetting,
                 int recurrencePeriod, int sortingPriority,
                 boolean sentNotification)
    {
        this.id = id;
        this.title = title;
        this.year = year;
        this.month = month;
        this.day = day;
        this.hour = hour;
        this.minute = minute;
        this.notificationSetting = notificationSetting;
        this.recurrencePeriod = recurrencePeriod;
        this.sortingPriority = sortingPriority;
        this.sentNotification = sentNotification;
        this.deleted = null;
    }
    public boolean isEventHappeningOnGivenDate(Calendar calendar)
    {
        return day == calendar.get(Calendar.DAY_OF_MONTH) &&
                month == calendar.get(Calendar.MONTH) &&
                year == calendar.get(Calendar.YEAR);
    }
    public boolean hasEventFinished(LocalTime localTime)
    {
        LocalTime eventTime = LocalTime.of(hour,minute);
        return localTime.isAfter(eventTime);
    }
    public static Event getEventForID(int passedEventID)
    {
        for (Event event : eventArrayList)
        {
            if(event.getId() == passedEventID)
                return event;
        }
        // return null if no event with matching ID was found
        return null;
    }
    public static ArrayList<Event> nonDeletedEvents()
    {
        ArrayList<Event> nonDeleted = new ArrayList<>();
        // Add every Event that does not have a deleted date
        // to the nonDeleted list
        for(Event event : eventArrayList)
        {
            if(event.getDeleted() == null)
            {
                nonDeleted.add(event);
            }
        }

        return nonDeleted;
    }
    public int getId()
    {
        return id;
    }
    public void setId(int id)
    {
        this.id = id;
    }
    public String getTitle()
    {
        return title;
    }
    public void setTitle(String title)
    {
        this.title = title;
    }
    public int getYear() {
        return year;
    }
    public void setYear(int year) {
        this.year = year;
    }
    public int getMonth() {
        return month;
    }
    public void setMonth(int month) {
        this.month = month;
    }
    public int getDay() {
        return day;
    }
    public void setDay(int day) {
        this.day = day;
    }
    public int getHour() {
        return hour;
    }
    public void setHour(int hour) {
        this.hour = hour;
    }
    public int getMinute() {
        return minute;
    }
    public void setMinute(int minute) {
        this.minute = minute;
    }
    public int getNotificationSetting(){
        return notificationSetting;
    }
    public void setNotificationSetting(int notificationSetting) {
        this.notificationSetting = notificationSetting;
    }
    public int getRecurrencePeriod() {
        return recurrencePeriod;
    }
    public void setRecurrencePeriod(int recurrencePeriod) {
        this.recurrencePeriod = recurrencePeriod;
    }
    public int getSortingPriority() {
        return sortingPriority;
    }
    public void setSortingPriority(int sortingPriority) {
        this.sortingPriority = sortingPriority;
    }
    public boolean getSentNotification() {return  sentNotification; }
    public void setSentNotification(boolean sentNotification) {this.sentNotification = sentNotification; }
    public Date getDeleted()
    {
        return deleted;
    }
    public void setDeleted(Date deleted)
    {
        this.deleted = deleted;
    }
}